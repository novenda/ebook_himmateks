<div class="content-wrapper">
    <section class="content">
        <?php foreach ($ebook as $ebk) { ?>

            <form action="<?php echo base_url().'ebook/update';?>" method="post">

    <div class="form-groub">
    <label>Judul Materi</label>
    <input type="hidden" name="id_ebook" class="form-control" 
    value="<?php echo $ebk->id_ebook ?>" >
    <input type="text" name="judul" class="form-control" 
    value="<?php echo $ebk->judul ?>" > 
    </div>

    <div class="form-groub">
    <label>Keterangan</label>
    <input type="text" name="keterangan" class="form-control" 
    value="<?php echo $ebk->keterangan ?>" >
    </div>

    <div class="form-groub">
    <label>Dokumen</label>
    <input type="text" name="dokumen" class="form-control" 
    value="<?php echo $ebk->dokumen ?>" >
    </div>

<button type="reset" class="btn btn-danger"> Reset </button>
<button type="submit" class="btn btn-primary"> Save </button>


                </form>
            <?php } ?>
        </section>
     </div>