<!DOCTYPE html>
    <head>

        <title>Contoh View</title>



        <body>

            <h1>haahahahahahahhaha</h1>

        </body>


    </head>
</html>