<div class="content-wrapper">
    <section class="content-header">
      <h1>
        Data Materi
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Data Materi </li>
      </ol>
    </section>

    <section class="content">
        <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"> <i class="fa fa-plus"></i>
        Tambah Materi</button>  
        <table class="table">
          <tr>
            <th>No</th>
            <th>Judul</th>
            <th>Keterangan</th>
            <th>Dokumen</th>
          </tr>

        <?php

        $no = 1;
        foreach ($ebook as $ebk) : ?>
          <tr>
            <td><?php echo $no++ ?></td>
            <td><?php echo $ebk->judul?></td>
            <td><?php echo $ebk->keterangan?></td>
            <td><?php echo $ebk->dokumen?></td>

            <td onclick="javascript: return confirm('Anda Yakin Hapus?')">
            <?php echo anchor('ebook/hapus/'.$ebk->id_ebook, 
            '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>') ?></td>

            <td><?php echo anchor('ebook/edit/'.$ebk->id_ebook,'<div class="btn btn-primary btn-sm">
            <i class="fa fa-edit"></i></div>')?></td>
          </tr>

          <?php endforeach?>

          </table>

          
    </section>

   
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Input Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo form_open_multipart ('ebook/tambah_aksi');?>
            <div class="form-grub">
            <label>Judul Materi</label>
            <input type="text" name="judul" class="form-control">

            <div class="form-grub">
            <label>Keterangan</label>
            <input type="text" name="keterangan" class="form-control">

            <div class="form-grub">
            <label>Dokumen</label>
            <input type="file" name="dokumen" class="form-control" value="upload">
            
            <div class="modal-footer">
            <button type="reset" class="btn btn-danger" data-dismiss="modal">reset</button>
            <button type="submit" class="btn btn-primary" value="upload">Save</button>
            </div>

            <?php echo form_close ();?>
    
      </div>
      
  </div>
</div>

</div>