<?php

class Hello extends CI_Controller {
    public function index () {

        $this->load->model('m_ebook');
        $data['ebook']= $this->m_ebook->get_data();
        $this->load->view('V_ebook', $data);
        $this->load->view('template/header');
		$this->load->view('template/sidebar');
		$this->load->view('template/footer');
		$this->load->view('dashboard');
    }

    public function upload () {
        echo "hello up..!!!";
        }
}

?>