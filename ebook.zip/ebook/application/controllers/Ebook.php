<?php

class Ebook extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('m_ebook');
        $this->load->helper('url');
        $this->load->helper(array('form', 'url'));
    }

    public function dashboard () {
        $this->load->view('dashboard');   
    }


    public function index () {

      
        $data['ebook']= $this->m_ebook->tampil_data()->result();
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('V_ebook', $data);
		$this->load->view('template/footer');
		
    }

    public function tambah_aksi (){

        $judul          = $this->input->post('judul');
        $keterangan     = $this->input->post('keterangan');
        $dokumen        = $_FILES['dokumen'];
        if ($dokumen=''){}else{
            $config['upload_path']  = './assets/dokumen';
            $config['allowed_types'] ='png|jpg|gif|pdf|docx';
        
            $config['overwrite']			= true;
            $config['max_size']             = 4024; // 1MB

            $this->load->library('upload', $config);
            if(!$this->upload->do_upload('dokumen')){
                echo "upload gagal"; die();
                
            }else{
                $dokumen=$this->upload->data('file_name');
            }
        }

        $data = array(
            'judul'         => $judul,
            'keterangan'    => $keterangan,
            'dokumen'       => $dokumen,
        );

        $this->m_ebook->input_data($data, 'tb_ebook');
        redirect('ebook/index');


    }

    public function hapus ($id_ebook)
    {
        $where = array('id_ebook' => $id_ebook);
        $this->m_ebook->hapus_data($where, 'tb_ebook');
        redirect('ebook/index');
    }

    public function edit ($id_ebook)
    {
        
        $where = array('id_ebook' => $id_ebook);
        $data['ebook'] = $this->m_ebook->edit_data($where,'tb_ebook')->result();
           
        
         $this->load->view('template/header');
         $this->load->view('template/sidebar');
       
         $this->load->view('V_edit', $data);
         $this->load->view('template/footer');
    }

    function update(){
        $id_ebook = $this->input->post('id_ebook');
        $judul = $this->input->post('judul');
        $keterangan = $this->input->post('keterangan');
        $dokumen = $this->input->post('dokumen');
     
        $data = array(
            
            'judul' => $judul,
            'keterangan' => $keterangan,
            'dokumen' => $dokumen
        );
     
        $where = array(
            'id_ebook' => $id_ebook
        );
     
        $this->m_ebook->update_data($where,$data,'tb_ebook');
        redirect('ebook/index');
    }
}

?>